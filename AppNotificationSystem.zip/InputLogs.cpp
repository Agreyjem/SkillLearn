//using namespace std;
//using namespace winrt;
//
//namespace winrt::AppNotificationSystem::implementation
//{
//	const wchar_t* eventText = L"Event: Have lunch!1";
//	const wchar_t* eventDesc = L"Go have a fun lunch with your friends";
//
//	//type "extern const wchar_t* eventText;" and "extern const wchar_t* eventDesc;"
//	//to pipe it into other cpp files.
//}